package com.angel.volunteer_system.volunteer.Entity;

/**
 * @Author: Angel_zou
 * @Date: Created in 22:15 2020/11/19
 * @Connection: ahacgn@gmail.com
 * @Description: User的顶级接口
 */
public interface MyUser {

}
